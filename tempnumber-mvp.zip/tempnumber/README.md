# TempNumber MVP

A Streamlit starter app for a legitimate temporary-SMS-number dashboard.

## Important limitation

This project does **not** generate real phone numbers by itself. Real numbers and incoming SMS require a legitimate telecom/virtual-number provider. This starter intentionally does not fabricate numbers or OTPs.

The app currently provides:
- Country selector (US, UK, Canada, Nigeria)
- Provider-connection status
- SMS inbox placeholder
- Basic safety/privacy guidance

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Deploy with GitHub + Streamlit Community Cloud

1. Create a GitHub repository named `tempnumber`.
2. Upload `app.py`, `requirements.txt`, and this `README.md`.
3. Open Streamlit Community Cloud and sign in with GitHub.
4. Choose **New app**, select the repository, branch, and `app.py`.
5. Deploy.

## Provider integration

Do not paste API keys into source code or commit them to GitHub.
When a provider has been vetted, store credentials in Streamlit app secrets:

```toml
PROVIDER_API_BASE = "https://provider.example/api"
PROVIDER_API_TOKEN = "your-secret-token"
```

The current starter detects credentials but does not make provider requests. Before enabling an integration, verify:
- whether it offers a genuinely free tier (not merely a free trial requiring payment);
- whether the selected country has numbers available;
- whether it supports inbound SMS;
- number rental duration and renewal/expiration rules;
- whether use for WhatsApp or other target services is permitted;
- applicable telecom, privacy, and data-protection requirements.

A provider may charge for number rental, SMS, or activation. Do not add payment details or purchase credit unless you explicitly decide to.
