import os
import requests
import streamlit as st
from datetime import datetime, timezone

st.set_page_config(page_title="TempNumber", page_icon="📩", layout="centered")

st.markdown("""
<style>
    .stApp {max-width: 900px; margin: auto;}
    .hero {padding: 1.4rem; border-radius: 18px; background: linear-gradient(120deg,#111827,#263b63); color: white;}
    .hero h1 {margin:0; font-size:2.2rem;}
    .hero p {margin:.45rem 0 0; color:#dbeafe;}
    .notice {padding: .9rem 1rem; border-radius: 12px; background:#fff7df; color:#694b00; border:1px solid #f1d58b;}
    .muted {color: #64748b; font-size:.9rem;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <h1>📩 TempNumber</h1>
  <p>A simple dashboard for temporary SMS numbers and incoming messages.</p>
</div>
""", unsafe_allow_html=True)

st.write("")
st.markdown(
    '<div class="notice"><b>Important:</b> This first version does not invent phone numbers. '
    'A real number and live SMS inbox require a legitimate number provider. '
    'We are keeping this setup at ₦0: no subscriptions, no payment details, and no fake OTPs.</div>',
    unsafe_allow_html=True
)

# Provider settings are added later through Streamlit secrets, never hard-coded.
API_BASE = st.secrets.get("PROVIDER_API_BASE", os.getenv("PROVIDER_API_BASE", "")).rstrip("/")
API_TOKEN = st.secrets.get("PROVIDER_API_TOKEN", os.getenv("PROVIDER_API_TOKEN", ""))

st.subheader("1. Choose a country")
countries = {
    "United States 🇺🇸": "US",
    "United Kingdom 🇬🇧": "GB",
    "Canada 🇨🇦": "CA",
    "Nigeria 🇳🇬": "NG",
}
country_label = st.selectbox("Country", list(countries.keys()))
country_code = countries[country_label]

st.subheader("2. Get a number")
st.caption("When a supported provider is connected, this button will request a real number from that provider.")

if not API_BASE or not API_TOKEN:
    st.info("No SMS provider is connected yet. The app is ready for an approved provider integration, but it cannot issue a real number until one is connected.")
    st.button("Get a number", disabled=True, use_container_width=True)
    with st.expander("Why is this button disabled?"):
        st.write(
            "Real phone numbers are issued and maintained by telecom/virtual-number providers. "
            "A free Streamlit app cannot create telephone numbers by itself. "
            "We will only connect a provider after checking its pricing, supported countries, "
            "SMS receiving capability, and rules for services such as WhatsApp."
        )
else:
    st.success("Provider credentials detected.")
    if st.button("Request number", type="primary", use_container_width=True):
        st.warning(
            "Provider integration is not enabled in this starter build. "
            "We need the provider's official API documentation and a confirmed zero-cost option before activating requests."
        )

st.divider()
st.subheader("3. SMS inbox")
st.write("Your incoming messages will appear here after a real number is assigned.")
st.info("No number has been assigned, so there are no messages to display.")

with st.expander("Privacy and safe use"):
    st.write(
        "- Use numbers only where the service permits virtual numbers.\n"
        "- Do not use public/shared inboxes for private accounts, banking, or sensitive information.\n"
        "- Anyone with access to a shared inbox may see its messages.\n"
        "- Never use this app to access accounts that do not belong to you."
    )

st.caption("TempNumber MVP • Built with Streamlit • " + datetime.now(timezone.utc).strftime("%Y"))
